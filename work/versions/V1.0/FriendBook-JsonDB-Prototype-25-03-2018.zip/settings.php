<?php
require_once "./include/pagelock.php";
require_once "./include/mainHeader.php";
?>
    <div id="left-col-grid">
        <div class="lwrap">
            <ul>
                <li>General</li>
                <li>Personal</li>
                <li>About</li>
                <li>Notifications</li>
            </ul>
        </div>
    </div>
    <div id="content-grid">
        content here
    </div>

<?php require_once "./include/mainFooter.php"; ?>