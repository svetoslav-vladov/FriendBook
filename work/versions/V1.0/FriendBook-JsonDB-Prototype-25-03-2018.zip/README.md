# FriendBook
**FriendBook is a new social network for side project in IT Talents Season 9 / PHP**
- Team: Svetoslav Vladov & Eray Myumyun 2017 - 2018
- Start date: 12/03/2018

PLAN:
- Front-controller / some AJAX / JSON for DB
- Transition to MySQL / PDO / OOP / more AJAX


