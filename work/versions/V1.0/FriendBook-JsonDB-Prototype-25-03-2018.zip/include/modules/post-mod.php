<form action="index.php" method="post">
    <textarea id="post-module" cols="62" rows="10" name="desc"></textarea>
    <input type="submit" value="post" name="add-post">
</form>