<div id="user-nav">
    <ul>
        <li><a href="#">News Feed</a></li>
        <li><a href="#">Profile page</a></li>
        <li><a href="#">Messages</a></li>
        <li><a href="./index.php?page=settings">Settings</a></li>
        <li><a href="#">friends</a></li>
    </ul>
</div>